<?php

namespace Pluginever\WCMinMaxQuantities\Admin;
class Admin_Menu{

}
