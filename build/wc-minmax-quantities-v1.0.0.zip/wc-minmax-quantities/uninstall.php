<?php
/**
 * WCMinMaxQuantities Uninstall
 *
 * Uninstalling WCMinMaxQuantities deletes user roles, pages, tables, and options.
 *
 * @package WCMinMaxQuantities\Uninstaller
 * @version 1.0.0
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
